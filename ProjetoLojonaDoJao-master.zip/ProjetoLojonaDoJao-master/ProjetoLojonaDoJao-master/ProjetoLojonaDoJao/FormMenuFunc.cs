﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoLojonaDoJao
{
    public partial class FormMenuFunc : Form
    {

        public Form1 frmPrim;
        public FormMenuFunc()
        {
            InitializeComponent();
    //        frmPrim = _form1;//..
            Designmenu();

        }

        private void Designmenu()
        {
            panelMediaSubMenu.Visible = false;
       

        }

        private void hideSubMenu()
        {

            if (panelMediaSubMenu.Visible == true)
                panelMediaSubMenu.Visible = false;
            if (MenuPanel2.Visible == true)
                MenuPanel2.Visible = false;
        }


        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void FormMenuFunc_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            showSubMenu(panelMediaSubMenu);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            hideSubMenu();

        }

        private void button3_Click(object sender, EventArgs e)
        {
           hideSubMenu();
        }

        private void button4_Click(object sender, EventArgs e)
        {
           hideSubMenu();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

       

        private void MenuPanel1_Paint(object sender, PaintEventArgs e)
        {
            showSubMenu(panelMediaSubMenu);
        }

        private void button6_Click(object sender, EventArgs e)
        {
           hideSubMenu ();
        }
    }
}
        